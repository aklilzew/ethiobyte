import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom'; // Added Link
import api from '../../../api/api'; // Adjust path as needed

// Import Icons
import { FiImage, FiPlusSquare, FiLoader, FiAlertCircle, FiCheckCircle, FiSave, FiXCircle, FiArrowLeft, FiType, FiFileText } from 'react-icons/fi';

const GalleryCreatePage = () => {
  // --- LOGIC (Unchanged) ---
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
  });
  const [loading, setLoading] = useState(false); // Renamed saving to loading
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // No initial data fetch needed for create page (unless categories etc. were involved)

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    if (!formData.name.trim()) { // Added trim()
      setError('Gallery name is required.');
      setLoading(false);
      return;
    }

    try {
      const response = await api.gallery.create(formData);
      setSuccess(`Gallery "${formData.name}" created successfully! ID: ${response.data.galleryId}`);
      setLoading(false);
      setFormData({ name: '', description: '' }); // Clear form

      setTimeout(() => {
        // Navigate to the new gallery's detail page
        navigate(`/admin/galleries/${response.data.galleryId}`);
      }, 2000); // Adjusted delay slightly

    } catch (err) {
      console.error("Error creating gallery:", err);
      setError(err.response?.data?.error || 'Failed to create gallery.');
      setLoading(false);
    }
  };

  // Using navigate(-1) for back button
  const handleGoBack = () => {
    navigate(-1);
  };
  // --- END OF LOGIC ---


  // --- UI Rendering (Enhanced with Tailwind, text-lg focus) ---
  return (
    <div className="bg-gray-100 min-h-screen p-6 lg:p-10">
      {/* Form Card Container */}
      <div className="max-w-2xl mx-auto bg-white shadow-xl rounded-lg overflow-hidden"> {/* Adjusted max-width */}
        {/* Form Header */}
        <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 border-b border-gray-200 relative"> {/* Changed gradient */}
           {/* Back Button */}
           <button
                onClick={handleGoBack}
                className="absolute top-4 left-4 inline-flex items-center gap-1.5 px-3 py-1.5 border border-gray-300 text-lg font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition" // text-lg
                title="Go back"
            >
                <FiArrowLeft size={20} />
                Back
           </button>
           <div className="text-center pt-8 sm:pt-0">
               <h1 className="text-3xl md:text-4xl font-bold text-gray-800 flex items-center justify-center gap-3"> {/* Larger text */}
                 <FiImage className="text-purple-600" /> {/* Gallery icon */}
                 Create New Gallery
               </h1>
               <p className="text-lg text-gray-500 mt-1">Provide a name and optional description.</p> {/* text-lg */}
           </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 md:p-8 space-y-8"> {/* Increased spacing */}
          {/* Success Message */}
          {success && (
            <div className="flex items-start gap-3 bg-green-50 border border-green-200 text-green-700 p-4 rounded-lg text-lg" role="alert"> {/* text-lg */}
              <FiCheckCircle className="h-6 w-6 flex-shrink-0 mt-0.5" />
              <span>{success}</span>
            </div>
          )}
          {/* Error Message */}
          {error && (
            <div className="flex items-start gap-3 bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg text-lg" role="alert"> {/* text-lg */}
              <FiAlertCircle className="h-6 w-6 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Name Field */}
          <div>
             {/* Label uses text-lg */}
            <label htmlFor="name" className="block text-lg font-medium text-gray-700 mb-2"> {/* Increased margin */}
              Gallery Name <span className="text-red-500 ml-1">*</span>
            </label>
            <div className="relative rounded-lg shadow-sm"> {/* Rounded-lg */}
                <div className="pointer-events-none absolute inset-y-0 left-0 pl-3.5 flex items-center"> {/* Adjusted padding */}
                    <FiType className="h-5 w-5 text-gray-400" />
                </div>
                 {/* Input uses text-lg */}
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  disabled={loading}
                  className="focus:ring-purple-500 focus:border-purple-500 block w-full pl-12 pr-3 py-3 text-lg border-gray-300 rounded-lg disabled:bg-gray-50" // text-lg, py-3, rounded-lg
                  placeholder="e.g., Summer Vacation 2024"
                />
            </div>
          </div>

          {/* Description Field */}
          <div>
             {/* Label uses text-lg */}
            <label htmlFor="description" className="block text-lg font-medium text-gray-700 mb-2"> {/* Increased margin */}
              Description (Optional)
            </label>
             {/* Textarea uses text-lg */}
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows="5" // Adjusted rows
              disabled={loading}
              className="shadow-sm focus:ring-purple-500 focus:border-purple-500 mt-1 block w-full text-lg border border-gray-300 rounded-lg disabled:bg-gray-50 p-3.5" // text-lg, p-3.5, rounded-lg
              placeholder="Add a brief description about this gallery..."
            />
          </div>


          {/* Action Buttons */}
          <div className="pt-8 border-t border-gray-200"> {/* Increased padding-top */}
            <div className="flex justify-end gap-4">
              <button
                type="button"
                onClick={handleGoBack}
                disabled={loading}
                 // Button uses text-lg
                className="inline-flex items-center justify-center px-6 py-3 border border-gray-300 shadow-sm text-lg font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:opacity-50" // text-lg, py-3, rounded-lg
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                 // Button uses text-lg
                className="inline-flex items-center justify-center px-6 py-3 border border-transparent shadow-sm text-lg font-medium rounded-lg text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:opacity-50" // text-lg, py-3, rounded-lg
              >
                {loading ? (
                    <>
                      <FiLoader className="animate-spin -ml-1 mr-3 h-5 w-5" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <FiSave size={20} className="-ml-1 mr-2" />
                      Create Gallery
                    </>
                  )}
              </button>
            </div>
          </div>
        </form>
      </div> {/* End Form Card Container */}
      {/* Removed the <style jsx> block */}
    </div>
  );
};

export default GalleryCreatePage;