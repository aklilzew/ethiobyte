import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../../api/api'; // Adjust path as needed
import { format } from 'date-fns'; // Optional: for date formatting

// Import Icons from react-icons/fi
import { FiImage, FiArrowLeft, FiLoader, FiAlertCircle, FiCheckCircle, FiTrash2, FiVideo, FiFileText, FiUpload, FiPaperclip, FiXCircle, FiCamera ,FiLayers} from 'react-icons/fi'; // Swapped Fa for Fi

const GalleryDetailPage = () => {
  // --- LOGIC (Unchanged) ---
  const { id: galleryId } = useParams();
  const navigate = useNavigate();
  const [gallery, setGallery] = useState(null);
  const [loading, setLoading] = useState(true); // Loading for initial gallery fetch
  const [mediaLoading, setMediaLoading] = useState(false); // Loading specifically for media list refresh
  const [error, setError] = useState(''); // General page/action errors
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [uploadSuccess, setUploadSuccess] = useState('');
  const [selectedFiles, setSelectedFiles] = useState([]);
  const fileInputRef = useRef(null);

  const fetchGalleryData = useCallback(async (showMediaLoading = false) => {
    if (showMediaLoading) {
        setMediaLoading(true); // Show media loading specifically
    } else {
        setLoading(true); // Show overall loading
    }
    setError(''); // Clear general errors on fetch
    try {
      const response = await api.gallery.getById(galleryId);
      setGallery(response.data);
    } catch (err) {
      console.error("Error fetching gallery details:", err);
      setError(err.response?.data?.error || 'Failed to load gallery details.');
      setGallery(null);
    } finally {
      setLoading(false); // Stop overall loading
      setMediaLoading(false); // Stop media loading
    }
  }, [galleryId]);

  useEffect(() => {
    fetchGalleryData();
  }, [fetchGalleryData]);

  const handleFileChange = (e) => {
    setSelectedFiles(Array.from(e.target.files));
    setUploadError(''); setUploadSuccess(''); // Clear upload messages
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) { setUploadError('Please select files.'); return; }
    setUploading(true); setUploadError(''); setUploadSuccess('');
    const formData = new FormData();
    selectedFiles.forEach(file => formData.append('media', file));
    try {
      const response = await api.gallery.addMedia(galleryId, formData);
      setUploadSuccess(`${response.data.count} media item(s) added!`);
      setSelectedFiles([]);
      if(fileInputRef.current) fileInputRef.current.value = "";
      await fetchGalleryData(true); // Refresh gallery data, show media loading
    } catch (err) {
      console.error("Error uploading media:", err);
      setUploadError(err.response?.data?.error || 'Failed to upload media.');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteMedia = async (mediaId, caption) => {
    if (window.confirm(`Delete media item "${caption || 'this item'}"?`)) {
      setError(''); // Clear general page errors
      // Optionally add a specific loading state for the item being deleted
      try {
        await api.gallery.removeMedia(galleryId, mediaId);
        // alert('Media removed successfully.'); // Consider using toast instead
        await fetchGalleryData(true); // Refresh gallery data, show media loading
      } catch (err) {
        console.error("Error removing media:", err);
        setError(err.response?.data?.error || 'Failed to remove media.'); // Use general error display
      }
      // Reset specific loading state if added
    }
  };

  const handleGoBack = () => { navigate('/admin/galleries'); };

  const getMediaUrl = (path) => {
    if (path?.startsWith('http://') || path?.startsWith('https://')) return path;
    const baseUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/';
    return path ? `${baseUrl}${path.replace(/\\/g, '/')}` : '';
  };

  const formatBytes = (bytes, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  // --- END OF LOGIC ---


  // --- UI Rendering (Enhanced with Tailwind, text-lg focus) ---

  // Loading State (Initial Fetch)
  if (loading && !gallery) {
    return (
      <div className="flex flex-col justify-center items-center min-h-[calc(100vh-10rem)] text-center p-10 bg-gray-50">
        <FiLoader className="animate-spin text-5xl text-blue-500 mb-4" />
        <p className="text-2xl text-gray-600">Loading gallery details...</p> {/* Larger text */}
      </div>
    );
  }

  // Error State (Initial Fetch Failed)
  if (error && !gallery) {
    return (
       <div className="bg-gray-100 min-h-screen p-6 lg:p-10">
         <div className="mb-6 flex flex-col items-center gap-4 bg-red-100 border border-red-300 text-red-800 p-6 rounded-lg shadow-md max-w-lg mx-auto text-center" role="alert">
           <FiAlertCircle className="h-10 w-10 text-red-600" />
           <div>
             <h3 className="text-xl font-semibold mb-2">Error Loading Gallery</h3> {/* Larger text */}
             <p className="text-lg">{error}</p> {/* Larger text */}
              <button
                onClick={handleGoBack}
                className="mt-4 inline-flex items-center gap-2 px-4 py-2 border border-transparent text-lg font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500" // Larger text
              >
                <FiArrowLeft size={20}/>
                Back to Galleries
              </button>
           </div>
         </div>
       </div>
    );
  }

   // Fallback if somehow gallery is null after loading and no error
   if (!gallery) {
     return (
       <div className="bg-gray-100 min-h-screen p-6 lg:p-10 text-center">
         <p className="text-lg text-gray-600">Gallery data could not be loaded.</p> {/* Larger text */}
         <button onClick={handleGoBack} className="mt-4 inline-block text-lg text-blue-600 hover:underline">Back to Galleries</button> {/* Larger text */}
       </div>
     );
   }


  // --- Main Content Display ---
  return (
    <div className="bg-gray-100 min-h-screen p-6 lg:p-10">
       <div className="max-w-6xl mx-auto"> {/* Increased max-width */}

           {/* Page Header with Back Button */}
           <div className="mb-8 flex items-center justify-between">
               <h1 className="text-4xl font-bold text-gray-800 tracking-tight flex items-center gap-3"> {/* Larger text */}
                 <FiImage className="text-purple-600" />
                 {gallery.name || 'Gallery Details'}
               </h1>
                <button
                    onClick={handleGoBack}
                    className="inline-flex items-center gap-1.5 px-4 py-2 border border-gray-300 text-lg font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition" // Larger text
                    title="Go back to gallery list"
                >
                    <FiArrowLeft size={20} />
                    Back
               </button>
           </div>

            {/* Optional Gallery Description & Owner */}
           <div className="mb-8 p-5 bg-white rounded-lg border border-gray-200 shadow-sm">
                <p className="text-lg text-gray-700 leading-relaxed"> {/* Larger text */}
                    {gallery.description || <span className="italic text-gray-500">No description provided for this gallery.</span>}
                </p>
                {gallery.owner && (
                    <p className="text-base text-gray-500 mt-3"> {/* text-base is fine here */}
                        Owner: <span className="font-medium">{gallery.owner}</span>
                    </p>
                )}
            </div>

           {/* General Error Display Area (for delete actions etc.) */}
           {error && (
                <div className="mb-6 flex items-start gap-3 bg-red-100 border border-red-300 text-red-800 p-5 rounded-lg shadow-sm" role="alert">
                  <FiAlertCircle className="h-6 w-6 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold">Error</h3> {/* Larger text */}
                    <p className="text-lg mt-1">{error}</p> {/* Larger text */}
                  </div>
                </div>
            )}

            {/* --- Media Upload Section --- */}
            <div className="mb-10 p-6 md:p-8 bg-white rounded-lg border border-gray-200 shadow-sm">
                <h2 className="text-2xl font-semibold text-gray-800 mb-5 flex items-center gap-2"> {/* Larger text */}
                   <FiUpload /> Add Media
                </h2>
                {/* Custom File Input Styling */}
                <div className="mb-4">
                    <label
                        htmlFor="media-upload-input"
                        className={`inline-flex items-center gap-2 px-5 py-3 border border-gray-300 rounded-lg shadow-sm text-lg font-medium cursor-pointer hover:bg-gray-50 ${uploading ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-white text-gray-700'}`} // Larger text/padding
                    >
                        <FiPaperclip size={20}/>
                        <span>{selectedFiles.length > 0 ? `${selectedFiles.length} file(s) selected` : 'Choose Files'}</span>
                    </label>
                    <input
                        type="file"
                        id="media-upload-input"
                        multiple
                        onChange={handleFileChange}
                        accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx"
                        disabled={uploading}
                        ref={fileInputRef}
                        className="sr-only" // Hide the default input
                    />
                     {/* Upload Button */}
                     {selectedFiles.length > 0 && (
                          <button
                            onClick={handleUpload}
                            disabled={uploading}
                            className="ml-4 inline-flex items-center justify-center px-5 py-3 border border-transparent shadow-sm text-lg font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50" // Larger text/padding
                          >
                             {uploading ? (
                                <><FiLoader className="animate-spin -ml-1 mr-3 h-5 w-5" /> Uploading...</>
                              ) : (
                                <><FiUpload size={20} className="-ml-1 mr-2" /> Upload</>
                              )}
                          </button>
                    )}
                </div>

                 {/* Selected Files Preview (Optional but helpful) */}
                {selectedFiles.length > 0 && !uploading && (
                    <div className="mt-4 p-4 border border-dashed border-gray-300 rounded-md bg-gray-50 max-h-40 overflow-y-auto">
                        <p className="text-base font-medium text-gray-600 mb-2">Selected:</p> {/* text-base */}
                        <ul className="list-disc list-inside space-y-1">
                            {selectedFiles.map((file, index) => (
                                <li key={index} className="text-base text-gray-700 truncate"> {/* text-base */}
                                   {file.name} <span className="text-gray-500">({formatBytes(file.size)})</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}

                {/* Upload Status Messages */}
                 <div className="mt-4 text-lg"> {/* Larger text */}
                    {uploadError && (
                        <p className="text-red-600 bg-red-50 p-3 rounded-md flex items-center gap-2">
                            <FiXCircle size={20}/> {uploadError}
                        </p>
                    )}
                    {uploadSuccess && (
                        <p className="text-green-600 bg-green-50 p-3 rounded-md flex items-center gap-2">
                           <FiCheckCircle size={20}/> {uploadSuccess}
                        </p>
                     )}
                 </div>
            </div>
            {/* --- End Media Upload Section --- */}


            {/* --- Media Display Section --- */}
            <div className="bg-white p-6 md:p-8 rounded-lg border border-gray-200 shadow-sm">
                <h2 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center justify-between"> {/* Larger text */}
                   <span className="inline-flex items-center gap-2"><FiLayers/> Gallery Media</span>
                   <span className="text-lg font-normal text-gray-500">({gallery.media?.length || 0} items)</span>
                </h2>

                {mediaLoading ? ( // Show media loading indicator
                    <div className="flex justify-center items-center py-10">
                         <FiLoader className="animate-spin text-3xl text-blue-500 mr-3" />
                         <span className="text-lg text-gray-500">Refreshing media...</span> {/* Larger text */}
                    </div>
                ) : gallery.media && gallery.media.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6"> {/* Increased gap */}
                    {gallery.media.map((item) => {
                        const mediaUrl = getMediaUrl(item.file_url);
                        return (
                            <div key={item.id} className="relative group border border-gray-200 rounded-lg overflow-hidden aspect-square flex flex-col justify-center items-center bg-gray-100"> {/* Aspect square for consistency */}

                                {item.media_type === 'image' ? (
                                <img
                                    src={mediaUrl}
                                    alt={item.alt_text || item.caption || 'Gallery image'}
                                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                                    loading="lazy" // Lazy load images
                                    onError={(e) => { e.target.src = 'https://via.placeholder.com/300?text=Error'; e.target.alt='Error loading image'}}
                                />
                                ) : item.media_type === 'video' ? (
                                    // Simplified video preview - consider a thumbnail or just an icon
                                    <div className="absolute inset-0 w-full h-full flex flex-col items-center justify-center bg-gray-800 text-white p-2">
                                        <FiVideo size={40} />
                                        <span className="text-xs mt-2 text-center line-clamp-1">{item.caption || 'Video'}</span>
                                        {/* Link to actual video */}
                                        <a href={mediaUrl} target="_blank" rel="noopener noreferrer" className="absolute inset-0" aria-label={`View video: ${item.caption || 'Video'}`}></a>
                                    </div>
                                ) : (
                                    // Document/Other Preview
                                    <a
                                        href={mediaUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="absolute inset-0 w-full h-full flex flex-col items-center justify-center bg-gray-200 text-gray-600 hover:bg-gray-300 p-2 transition-colors"
                                        aria-label={`View file: ${item.caption || 'File'}`}
                                    >
                                        <FiFileText size={40} />
                                        <span className="text-xs mt-2 text-center line-clamp-2">{item.caption || 'View File'}</span>
                                    </a>
                                )}

                                {/* Overlay with Caption and Delete Button - Shown on Hover */}
                                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 via-black/50 to-transparent p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex justify-between items-end">
                                    <p className="text-base text-white font-medium truncate mr-2" title={item.caption}> {/* text-base */}
                                        {item.caption || <span className="italic">No caption</span>}
                                    </p>
                                    <button
                                        onClick={() => handleDeleteMedia(item.id, item.caption)}
                                        className="flex-shrink-0 p-1.5 rounded-full bg-red-600 text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black/50 focus:ring-red-500"
                                        title="Delete Media"
                                    >
                                        <FiTrash2 size={18} /> {/* Adjusted size */}
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                  </div>
                ) : (
                    // No media state
                    <div className="text-center py-16 px-4 border border-dashed border-gray-300 rounded-lg">
                       <FiCamera className="mx-auto h-14 w-14 text-gray-400"/> {/* Changed icon */}
                       <p className="mt-4 text-lg text-gray-500">This gallery is empty.</p> {/* Larger text */}
                       <p className="mt-1 text-base text-gray-500">Use the upload section above to add media.</p> {/* text-base */}
                   </div>
                )}
            </div>
            {/* --- End Media Display Section --- */}
       </div>
      {/* Removed the <style jsx> block */}
    </div>
  );
};

export default GalleryDetailPage;