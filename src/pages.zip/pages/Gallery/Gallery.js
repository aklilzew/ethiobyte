import React from 'react';
import { FaCalendarAlt, FaUser, FaChevronLeft, FaChevronRight } from 'react-icons/fa';

const heroBgUrl = 'https://images.unsplash.com/photo-1581803118522-7b72a50f7e9f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80'; // Replace with your hero background
const imgWork1 = 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'; // Replace
const imgWork2 = 'https://images.unsplash.com/photo-1511050191711-99d61d1a900d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'; // Replace
const imgWork3 = 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'; // Replace
const videoThumb1 = 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'; // Replace with video thumbnail

const GalleryCard = ({ imageUrl, date, author, title, buttonText, buttonAction }) => {
    return (
      <div className="bg-white rounded-lg shadow-md overflow-hidden flex flex-col h-full"> 
        <img src={imageUrl} alt={title} className="w-full h-48 object-cover" />
        <div className="p-4 flex flex-col flex-grow"> 
          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
            <span className="flex items-center space-x-1">
              <FaCalendarAlt className="text-blue-600" />
              <span>{date}</span>
            </span>
            <span className="flex items-center space-x-1">
              <FaUser className="text-blue-600" />
              <span>{author}</span>
            </span>
          </div>
          <h3 className="font-semibold text-lg text-gray-800 mb-3 flex-grow min-h-[3rem]">
              {title}
          </h3>
          <div className="mt-auto pt-2"> 
              <button
                onClick={buttonAction}
                className="bg-blue-800 text-white px-4 py-2 rounded hover:bg-blue-900 transition-colors text-sm font-medium" // Just the core styles
              >
                {buttonText}
              </button>
          </div>
        </div>
      </div>
    );
  };

const Gallery = () => {
  const imageData = [
    { id: 1, imageUrl: imgWork1, date: '26 April 2025', author: 'Admin', title: 'Emergency Tech Trends What to in the next Decade' },
    { id: 2, imageUrl: imgWork2, date: '26 April 2025', author: 'Admin', title: 'Emergency Tech Trends What to in the next Decade' },
    { id: 3, imageUrl: imgWork3, date: '26 April 2025', author: 'Admin', title: 'Emergency Tech Trends What to in the next Decade' },
  ];

  const videoData = [
    { id: 1, imageUrl: videoThumb1, date: '26 April 2025', author: 'Admin', title: 'Emergency Tech Trends What to in the next Decade' },
    { id: 2, imageUrl: videoThumb1, date: '26 April 2025', author: 'Admin', title: 'Emergency Tech Trends What to in the next Decade' },
    { id: 3, imageUrl: videoThumb1, date: '26 April 2025', author: 'Admin', title: 'Emergency Tech Trends What to in the next Decade' },
  ];

  const handleViewMore = (id) => {
    console.log(`View More clicked for image id: ${id}`);
  };

  const handlePlay = (id) => {
    console.log(`Play clicked for video id: ${id}`);
  };

  const handlePrev = (type) => console.log(`Previous ${type}`);
  const handleNext = (type) => console.log(`Next ${type}`);


  return (
    <div>
      <div
        className="relative bg-cover bg-center h-64 md:h-80 flex items-center justify-center mt-16"
        style={{ backgroundImage: `url(${heroBgUrl})` }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        <h1 className="text-4xl md:text-5xl font-bold text-white z-10">
          Our Gallery
        </h1>
      </div>

      <section className="py-12 md:py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8 flex-wrap">
             <div className="text-center sm:text-left w-full sm:w-auto mb-4 sm:mb-0">
                 <p className="text-red-600 text-sm font-semibold mb-1">Gallery</p>
                 <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                 Our Previous Works Images
                 </h2>
             </div>
             <div className="flex space-x-2 mx-auto sm:mx-0">
                <button onClick={() => handlePrev('images')} aria-label="Previous Images" className="border border-red-500 text-red-500 p-2 rounded hover:bg-red-500 hover:text-white transition-colors">
                    <FaChevronLeft />
                </button>
                <button onClick={() => handleNext('images')} aria-label="Next Images" className="border border-red-500 text-red-500 p-2 rounded hover:bg-red-500 hover:text-white transition-colors">
                    <FaChevronRight />
                </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {imageData.map((item) => (
              <GalleryCard
                key={item.id}
                imageUrl={item.imageUrl}
                date={item.date}
                author={item.author}
                title={item.title}
                buttonText="View More"
                buttonAction={() => handleViewMore(item.id)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-white">
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
                 <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                 Our Previous Works Videos
                 </h2>
                 <div className="flex space-x-2 justify-center">
                    <button onClick={() => handlePrev('videos')} aria-label="Previous Videos" className="border border-red-500 text-red-500 p-2 rounded hover:bg-red-500 hover:text-white transition-colors">
                        <FaChevronLeft />
                    </button>
                    <button onClick={() => handleNext('videos')} aria-label="Next Videos" className="border border-red-500 text-red-500 p-2 rounded hover:bg-red-500 hover:text-white transition-colors">
                        <FaChevronRight />
                    </button>
                 </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {videoData.map((item) => (
                <GalleryCard
                    key={item.id}
                    imageUrl={item.imageUrl}
                    date={item.date}
                    author={item.author}
                    title={item.title}
                    buttonText="Play"
                    buttonAction={() => handlePlay(item.id)}
                />
                ))}
            </div>
        </div>
      </section>

    </div>
  );
};

export default Gallery;