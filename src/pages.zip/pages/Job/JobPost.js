import React from 'react';
import { FaCalendarAlt, FaUser, FaChevronLeft, FaChevronRight, FaMapMarkerAlt, FaBriefcase } from 'react-icons/fa'; // Added MapMarker and Briefcase, kept others for example flexibility

import heroBgImage from '../../image/carousel-1.jpg'; 
import jobImg1 from '../../image/carousel-2.jpg';      
import jobImg2 from '../../image/carousel-3.jpg';    
import jobImg3 from '../../image/carousel-3.jpg';   


const jobPosts = [
  {
    id: 'job-1',
    imageUrl: jobImg1,
    location: 'New York, USA',
    jobType: 'Full-Time',
    title: 'Senior Project Manager - Construction', 
    link: '#', 
  },
  {
    id: 'job-2',
    imageUrl: jobImg2,
    location: 'London, UK',
    jobType: 'Contract',
    title: 'Lead Civil Engineer - Infrastructure', 
    link: '#',
  },
  {
    id: 'job-3',
    imageUrl: jobImg3,
    location: 'Remote',
    jobType: 'Part-Time',
    title: 'Architectural Drafter - Commercial', 
    link: '#',
  },
];


const JobPost = () => {
  const handlePrevClick = () => {
    console.log('Previous clicked');
  };

  const handleNextClick = () => {
    console.log('Next clicked');
  };

  return (
    <div>
      <div
        className="relative bg-cover bg-center py-24 md:py-32 text-center text-white mt-16"
        style={{ backgroundImage: `url(${heroBgImage})` }}
      >
        <div className="absolute inset-0 bg-black opacity-30"></div>

        <div className="relative z-10 container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold">Job Post</h1>
        </div>
      </div>

      <div className="py-16 md:py-24 bg-gray-50"> 
        <div className="container mx-auto px-4">

        
          <div className="flex flex-col md:flex-row justify-between items-center mb-12 md:mb-16">
            <div className="text-center md:text-left mb-6 md:mb-0">
              <p className="text-orange-600 font-semibold uppercase tracking-wider mb-2 text-sm md:text-base">
                Career Opportunities
              </p>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Our Latest Job Post
              </h2>
            </div>

           
            <div className="flex space-x-3">
              <button
                onClick={handlePrevClick}
                aria-label="Previous Job Posts"
                className="p-2 border-2 border-red-500 text-red-500 rounded-sm hover:bg-red-500 hover:text-white transition duration-300 focus:outline-none focus:ring-2 focus:ring-red-300"
              >
                <FaChevronLeft />
              </button>
              <button
                onClick={handleNextClick}
                aria-label="Next Job Posts"
                className="p-2 border-2 border-red-500 text-red-500 rounded-sm hover:bg-red-500 hover:text-white transition duration-300 focus:outline-none focus:ring-2 focus:ring-red-300"
              >
                <FaChevronRight />
              </button>
            </div>
          </div>

         
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
            {jobPosts.map((post) => (
              <div key={post.id} className="bg-white shadow-lg rounded-lg overflow-hidden flex flex-col">
                <div className="relative">
                  <img
                    src={post.imageUrl}
                    alt={post.title}
                    className="w-full h-56 object-cover" 
                  />
                </div>

              
                <div className="p-6 flex flex-col flex-grow">
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-gray-600 mb-4">
                    <span className="flex items-center">
                      <FaMapMarkerAlt className="mr-1.5 text-orange-600" />
                      {post.location}
                    </span>
                    <span className="flex items-center">
                      <FaBriefcase className="mr-1.5 text-orange-600" />
                      {post.jobType}
                    </span>
                  </div>

                 
                  <h3 className="text-xl font-semibold text-gray-800 mb-4 flex-grow">
                    <a href={post.link} className="hover:text-orange-600 transition duration-300">
                      {post.title}
                    </a>
                  </h3>

                 
                  <div className="mt-auto">
                    <a
                      href={post.link}
                      className="inline-block bg-blue-900 text-white px-5 py-2 rounded font-medium text-sm hover:bg-blue-800 transition duration-300"
                    >
                      View More 
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobPost;