import React from 'react';

import heroBgImage from '../../image/fabe2.png';
import heroBgImage2 from '../../image/fabe.png';
import heroBgImage3 from '../../image/fabe3.png';
import heroBgImage4 from '../../image/fabe4.png'; 



const completedProjects = [
  {
    id: 'comp-1',
    imageUrl: heroBgImage, 
    category: 'Architecture',
    title: 'We build Everything',
    description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur tempore perferendis velit minus, perspiciatis eveniet adipisci tempora voluptatem quis dolores.',
    link: '#',
  },
  {
    id: 'comp-2',
    imageUrl: heroBgImage2, 
    category: 'Architecture',
    title: 'We build Everything',
    description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur tempore perferendis velit minus, perspiciatis eveniet adipisci tempora voluptatem quis dolores.',
    link: '#',
  },
];

const ongoingProjects = [
  {
    id: 'ong-1',
    imageUrl: heroBgImage3, 
    category: 'Architecture',
    title: 'We build Everything',
    description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur tempore perferendis velit minus, perspiciatis eveniet adipisci tempora voluptatem quis dolores.',
    link: '#',
  },
  {
    id: 'ong-2',
    imageUrl: heroBgImage4, 
    category: 'Architecture',
    title: 'We build Everything',
    description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur tempore perferendis velit minus, perspiciatis eveniet adipisci tempora voluptatem quis dolores.',
    link: '#',
  },
];


const Projects = () => {
  return (
    <div>
      <div
        className="relative bg-cover bg-center py-24 md:py-32 text-center text-white mt-16"
        style={{ backgroundImage: `url(${heroBgImage})` }} 
      >
        <div className="absolute inset-0 bg-black opacity-30"></div>

        <div className="relative z-10 container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold">Our Projects</h1>
        </div>
      </div>

      <div className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 md:mb-16">
            <p className="text-[#ff4500] font-semibold uppercase tracking-wider mb-2 text-sm md:text-base">
              Our Projects
            </p>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Recent Completed Projects
            </h2>
          </div>

        
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16">
            {completedProjects.map((project) => (
              <div key={project.id} className="flex flex-col sm:flex-row items-start gap-6">
                <div className="flex-shrink-0 w-full sm:w-48 lg:w-56 h-40 rounded overflow-hidden"> 
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-grow">
                  <p className="text-sm text-gray-600 mb-1">{project.category}</p>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {project.title}
                  </h3>
                  <p className="text-gray-700 text-sm mb-4">
                    {project.description}
                  </p>
                  <a
                    href={project.link}
                    className="inline-block bg-blue-900 text-white px-5 py-2 rounded font-medium text-sm hover:bg-blue-800 transition duration-300"
                  >
                    Read More
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="py-16 md:py-24 bg-white"> 
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Ongoing projects
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16">
            {ongoingProjects.map((project) => (
              <div key={project.id} className="flex flex-col sm:flex-row items-start gap-6">
                 <div className="flex-shrink-0 w-full sm:w-48 lg:w-56 h-40 rounded overflow-hidden"> 
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-grow">
                  <p className="text-sm text-gray-600 mb-1">{project.category}</p>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {project.title}
                  </h3>
                  <p className="text-gray-700 text-sm mb-4">
                    {project.description}
                  </p>
                  <a
                    href={project.link}
                    className="inline-block bg-blue-900 text-white px-5 py-2 rounded font-medium text-sm hover:bg-blue-800 transition duration-300"
                  >
                    Read More
                  </a>
                </div>
              </div>
            ))}
          </div>

           <div className="text-center mt-12 md:mt-16">
                <a
                    href="/services" 
                    className="inline-block bg-[#ff4500] text-white px-8 py-3 rounded font-bold text-base hover:bg-orange-700 transition duration-300"
                >
                    More Services
                </a>
            </div>

        </div>
      </div>
    </div>
  );
};

export default Projects;