import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import bg1 from '../../image/fabe.png'; // Ensure these paths are correct
import bg2 from '../../image/fabe2.png';
import bg3 from '../../image/fabe3.png';

const backgrounds = [bg1, bg2, bg3];


const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      delay: 0.7,
      delayChildren: 1.5,
      staggerChildren: 0.3,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: 'spring',
      damping: 15,
      stiffness: 60,
    },
  },
};

const buttonEnterVariant = {
    hidden: { opacity: 0, scale: 0.7 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        type: 'spring',
        damping: 12,
        stiffness: 100,
      },
    },
  };


const textShadowStyle = { textShadow: '1px 1px 4px rgba(0, 0, 0, 0.6)' };


const Home = () => {
  const [currentBg, setCurrentBg] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBg((prev) => (prev + 1) % backgrounds.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section
      id="home"
      className="relative z-0 min-h-screen overflow-hidden flex items-center justify-center text-white"
    >
      <motion.div
        className="absolute inset-0 bg-gray-100 z-20"
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ duration: 0.8, delay: 0.5 }}
      />

      {backgrounds.map((bg, index) => (
        <motion.div
          key={index}
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${bg})` }}
          initial={{ opacity: 0, scale: 1 }}
          animate={{
            opacity: currentBg === index ? 1 : 0,
            scale: currentBg === index ? 1.1 : 1,
          }}
          transition={{
            opacity: { duration: 1.5, ease: 'easeOut' },
            scale: { duration: 8.0, ease: 'easeOut' }
          }}
        />
      ))}

      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent z-10" />

      <motion.div
        className="relative z-30 container mx-auto px-4 text-center flex flex-col items-center max-w-4xl"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.span
          className="text-sm md:text-base font-semibold text-[#ff4500] uppercase tracking-widest mb-3"
          style={textShadowStyle}
          variants={itemVariants}
        >
          Construction Business
        </motion.span>

        <motion.h1
          className="text-5xl md:text-6xl lg:text-7xl font-extrabold leading-tight mb-5"
          style={textShadowStyle}
          variants={itemVariants}
        >
          We Build Ready Mix <br /> Concrete
        </motion.h1>

        <motion.p
          className="text-base md:text-lg lg:text-xl max-w-3xl mb-10 text-gray-100"
          style={textShadowStyle}
          variants={itemVariants}
        >
          Fabe Trading PLC manufactures top-quality ready mix concrete for construction projects,
          real estate developers, and various clients throughout Addis Ababa and its surrounding areas.
        </motion.p>

        <motion.div
          className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6"
          variants={itemVariants} // The group animates in using itemVariants
        >
          <motion.button
            className="bg-[#06367C] hover:bg-[#ff4500] text-white font-bold text-xl px-8 py-4 shadow-lg transition duration-300 ease-in-out transform hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-[#ff7e5f] focus:ring-opacity-50" // Added hover:bg-blue-600
            variants={buttonEnterVariant}
            whileTap={{ scale: 0.95, transition: { type: 'spring', stiffness: 400, damping: 15 } }}
          >
            Subscribe
          </motion.button>

          <motion.button
            className="bg-[#FF4502] hover:bg-[#06367C] text-white font-bold text-xl px-8 py-4 shadow-lg transition duration-300 ease-in-out transform hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-white focus:ring-opacity-75" // Added hover:bg-blue-600
            variants={buttonEnterVariant}
            whileTap={{ scale: 0.95, transition: { type: 'spring', stiffness: 400, damping: 15 } }}
          >
            Our Projects
          </motion.button>
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Home;