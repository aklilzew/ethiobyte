import React from 'react';
import { FaCalendarAlt, FaUser } from 'react-icons/fa'; 
import img1 from '../../image/carousel-1.jpg'
import img2 from '../../image/about-2.jpg'
import img3 from '../../image/about-3.jpg'


const posts = [
  {
    id: 1,
    imageUrl: img1, 
    date: '26 April 2025',
    author: 'Admin',
    title: 'Emergency Tech Trends What to in the next Decade',
    link: '#', 
  },
  {
    id: 2,
    imageUrl: img2, 
    date: '26 April 2025',
    author: 'Admin',
    title: 'Emergency Tech Trends What to in the next Decade',
    link: '#',
  },
  {
    id: 3,
    imageUrl: img3, 
    date: '26 April 2025',
    author: 'Admin',
    title: 'Emergency Tech Trends What to in the next Decade',
    link: '#',
  },
  
];

const Blog = () => {
  return (
    <div>
      <div
        className="relative bg-cover bg-center py-32 text-center text-white mt-16"
        style={{ backgroundImage: `url(${img1})` }}
      >
       
        <div className="absolute inset-0 bg-black opacity-20"></div>

       
        <div className="relative z-10 container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our News & Blog</h1>
          <div className="text-lg">
            <span>Home</span>
            <span className="mx-2">/</span>
            <span>Pages</span>
            <span className="mx-2">/</span>
            <span className="font-semibold">Blog</span>
          </div>
        </div>
      </div>

    
      <div className="py-16 md:py-24 bg-gray-50"> 
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 md:mb-16">
            <p className="text-red-600 font-semibold uppercase tracking-wider mb-2">News & Blogs</p>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800">
              Our Latest News Post And Articles?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
            {posts.map((post) => (
              <div key={post.id} className="bg-white shadow-lg rounded-lg overflow-hidden flex flex-col">
                <div className="relative">
                    <img
                        src={post.imageUrl}
                        alt={post.title}
                        className="w-full h-56 object-cover" 
                    />
                </div>

              
                <div className="p-6 flex flex-col flex-grow"> 
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                    <span className="flex items-center">
                      <FaCalendarAlt className="mr-1 text-red-600" />
                      {post.date}
                    </span>
                    <span className="flex items-center">
                      <FaUser className="mr-1 text-red-600" />
                      {post.author}
                    </span>
                  </div>

                 
                  <h3 className="text-xl font-semibold text-gray-800 mb-4 flex-grow"> 
                    <a href={post.link} className="hover:text-red-600 transition duration-300">
                      {post.title}
                    </a>
                  </h3>

                 
                  <div className="mt-auto">
                    <a
                      href={post.link}
                      className="inline-block bg-red-600 text-white px-5 py-2 rounded font-medium text-sm hover:bg-red-700 transition duration-300"
                    >
                      Read More
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;